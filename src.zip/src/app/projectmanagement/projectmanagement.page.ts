import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-projectmanagement',
  templateUrl: './projectmanagement.page.html',
  styleUrls: ['./projectmanagement.page.scss'],
})
export class ProjectmanagementPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
