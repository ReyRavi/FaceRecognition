import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leavemanagement',
  templateUrl: './leavemanagement.page.html',
  styleUrls: ['./leavemanagement.page.scss'],
})
export class LeavemanagementPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
